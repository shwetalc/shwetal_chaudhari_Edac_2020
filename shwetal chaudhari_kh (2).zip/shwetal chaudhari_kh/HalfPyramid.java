class InvertedHalfPyramid
{
   public static void main(String args[])
{ 
   
   for(int i=6;i>=1;i++)
{
    for(int j=1;j<=6;j--)
{
    System.out.print("*");
}
    System.out.println();
}
}
}
    