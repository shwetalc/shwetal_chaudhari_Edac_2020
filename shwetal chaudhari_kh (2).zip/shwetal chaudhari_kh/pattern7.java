class Pattern7
{
   public static void main(String args[])
{
    int i,j,k;
    int n=9;
    int z=n*2-1; 
    for(i=9;i>=1;i--)
{
    for(j=n-1;j>=i;j--){
       System.out.print(" ");
}
    for(k=1;k<=z;k++){
        System.out.print(i);
}
     z=z-2;
    System.out.println();
}
     

     
}
   
}