class FullPyramid1
{
  public static void main(String args[])
{
  int i,j,k;
  int z=1;
  for(i=1;i<=6;i++)
{
   for(j=5;j>=i;j--)
  {
    System.out.print(" ");
  }
   for(k=1;k<=z;k++)
{
    System.out.print("*");
}
    z=z+2;
    System.out.println();
}
}
}
  